# Test
contain api for ATM vendor machine
api for signup for admin
api for sign up for user
user can withdraw after login
admin can add deposit after login
